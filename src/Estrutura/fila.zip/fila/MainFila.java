package Estrutura.fila;

public class MainFila {
    public static void main(String[] args) {
        Fila fila = new Fila(5);
        fila.inserirElementos(2004);
        fila.inserirElementos(2003);
        fila.inserirElementos(2001);
        fila.percorreLista();
        fila.removerElemento();
        fila.percorreLista();
    }
}
